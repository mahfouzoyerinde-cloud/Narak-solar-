package com.naraksolar.energy

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val orange = Color.rgb(245, 106, 10)
    private val ink = Color.rgb(35, 39, 42)
    private val muted = Color.rgb(105, 110, 115)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var devices: LinearLayout
    private var scanner: BluetoothLeScanner? = null
    private val found = linkedMapOf<String, BluetoothDevice>()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 22, 20, 24); setBackgroundColor(Color.rgb(255, 248, 242)) }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply { text = "NARAK"; textSize = 30f; setTextColor(orange); setTypeface(null, 1) })
        root.addView(TextView(this).apply { text = "SOLAR ENERGY"; textSize = 17f; setTextColor(ink); setTypeface(null, 1) })
        root.addView(TextView(this).apply { text = "Solar • Inverter • Battery • BMS"; textSize = 14f; setTextColor(muted); setPadding(0, 4, 0, 18) })
        card("BATTERY / BMS", "Connect your compatible battery BMS to view live readings.\nTAICO protocol is not yet identified.")
        card("SOLAR PANELS", "Solar input readings will appear here when a supported inverter protocol is added.")
        card("INVERTER", "Inverter readings are not connected yet.")
        root.addView(TextView(this).apply { text = "BLUETOOTH DEVICES"; textSize = 18f; setTextColor(ink); setTypeface(null, 1); setPadding(0, 18, 0, 8) })
        status = TextView(this).apply { text = "Ready to scan nearby Bluetooth devices."; textSize = 14f; setTextColor(muted); setPadding(0, 4, 0, 12) }
        root.addView(status)
        root.addView(Button(this).apply { text = "SCAN FOR DEVICES"; setTextColor(Color.WHITE); setBackgroundColor(orange); setOnClickListener { startScan() } })
        devices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 8, 0, 0) }
        root.addView(devices)
        root.addView(TextView(this).apply { text = "Note: this starter app scans Bluetooth devices only. It does not yet read battery data or control equipment. A compatible TAICO BMS protocol must be identified before live readings can work."; textSize = 12f; setTextColor(muted); setPadding(0, 22, 0, 8) })
    }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); setBackgroundColor(Color.WHITE) }
        box.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(orange); setTypeface(null, 1) })
        box.addView(TextView(this).apply { text = body; textSize = 14f; setTextColor(ink); setPadding(0, 8, 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, 12); root.addView(box, lp)
    }

    private fun startScan() {
        val permissions = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 42); return }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        if (adapter == null || !adapter.isEnabled) { status.text = "Please turn on Bluetooth, then scan again."; return }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) { status.text = "Bluetooth LE scanning is unavailable on this phone."; return }
        found.clear(); devices.removeAllViews()
        status.text = "Scanning for 12 seconds…"
        try { scanner?.startScan(callback) } catch (e: SecurityException) { status.text = "Bluetooth permission is required."; return }
        handler.postDelayed({
            try { scanner?.stopScan(callback) } catch (_: Exception) {}
            status.text = if (found.isEmpty()) "No Bluetooth LE devices found. Keep the BMS awake and try again." else "Found ${found.size} device(s). Tap a device to see its address."
        }, 12000)
    }

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            runOnUiThread {
                val d = result.device
                val key = try { d.address } catch (_: SecurityException) { result.hashCode().toString() }
                if (!found.containsKey(key)) {
                    found[key] = d
                    val name = try { d.name ?: "Unnamed Bluetooth device" } catch (_: SecurityException) { "Bluetooth device" }
                    devices.addView(TextView(this@MainActivity).apply {
                        text = "$name\n$key  •  Signal ${result.rssi} dBm"
                        textSize = 14f; setTextColor(ink); setPadding(12, 12, 12, 12); setBackgroundColor(Color.WHITE)
                        setOnClickListener { status.text = "Selected: $name. Reading data requires the correct BMS protocol." }
                    }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 6) })
                }
            }
        }
        override fun onScanFailed(errorCode: Int) { runOnUiThread { status.text = "Bluetooth scan failed (code $errorCode). Check Bluetooth and permissions." } }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
            else status.text = "Bluetooth permission was not granted. Allow it to scan devices."
        }
    }

    override fun onDestroy() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        super.onDestroy()
    }
}
