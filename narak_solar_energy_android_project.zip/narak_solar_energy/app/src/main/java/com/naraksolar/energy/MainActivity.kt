package com.naraksolar.energy

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val orange = Color.rgb(238, 116, 0)
    private val dark = Color.rgb(40, 43, 48)
    private lateinit var status: TextView
    private lateinit var results: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        requestNeededPermissions()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 24)
            setBackgroundColor(Color.rgb(255, 250, 245))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "NARAK SOLAR ENERGY"
            textSize = 24f; setTextColor(orange); setTypeface(null, 1)
        }
        val subtitle = TextView(this).apply {
            text = "Solar • Battery • Inverter Monitor"
            textSize = 14f; setTextColor(dark); setPadding(0, 4, 0, 18)
        }
        content.addView(title); content.addView(subtitle)
        content.addView(section("SYSTEM OVERVIEW"))
        content.addView(card("Battery voltage", "12V / 24V / 48V — demo reading"))
        content.addView(card("Battery level", "78% — simulated data"))
        content.addView(card("Solar input", "420 W — simulated data"))
        content.addView(card("Inverter status", "Waiting for compatible device"))
        content.addView(TextView(this).apply {
            text = "Demo values only: live readings will appear after a compatible BMS/inverter protocol is integrated and connected."
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(0, 8, 0, 16)
        })
        content.addView(section("DEVICE CONNECTIONS"))
        content.addView(button("Scan Bluetooth devices") { scanBluetooth() })
        content.addView(button("Scan Wi-Fi networks") { scanWifi() })
        status = TextView(this).apply {
            text = "Ready. Grant nearby-device permissions when requested."
            textSize = 14f; setTextColor(dark); setPadding(0, 14, 0, 8)
        }
        results = TextView(this).apply { textSize = 13f; setTextColor(dark); setPadding(0, 4, 0, 20) }
        content.addView(status); content.addView(results)
        content.addView(section("SUPPORTED SYSTEMS (PLANNED)"))
        content.addView(TextView(this).apply {
            text = "• 12V, 24V and 48V batteries\n• LiFePO₄, other lithium and lead-acid\n• Bluetooth BMS devices\n• Wi-Fi-enabled inverters\n• RS-485 / CAN via compatible external adapters\n• Local monitoring; remote monitoring requires a secure backend"
            textSize = 14f; setTextColor(dark); setPadding(0, 8, 0, 20)
        })
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(orange); setTypeface(null, 1)
        setPadding(0, 12, 0, 8)
    }

    private fun card(label: String, value: String) = TextView(this).apply {
        text = "$label\n$value"; textSize = 16f; setTextColor(dark)
        setPadding(16, 14, 16, 14); setBackgroundColor(Color.WHITE)
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 9; layoutParams = lp
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); setBackgroundColor(orange)
        isAllCaps = false; setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 8; layoutParams = lp
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        if (permissions.isNotEmpty()) requestPermissions(permissions.toTypedArray(), 100)
    }

    @Suppress("MissingPermission")
    private fun scanBluetooth() {
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null) { status.text = "This phone does not support Bluetooth."; return }
            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                requestNeededPermissions(); status.text = "Allow Bluetooth scan permission, then tap scan again."; return
            }
            if (!adapter.isEnabled) { status.text = "Turn on Bluetooth in phone settings, then scan again."; return }
            val bonded = adapter.bondedDevices
            val names = bonded.map { device -> "• ${device.name ?: "Unnamed device"} (${device.address})" }
            status.text = "Bluetooth is on. Paired devices shown below; active BLE discovery is not yet implemented."
            results.text = if (names.isEmpty()) "No paired devices found. Pair your BMS in Android Bluetooth settings first." else names.joinToString("\n")
        } catch (e: SecurityException) { status.text = "Bluetooth permission missing. Allow it in app settings and retry." }
    }

    @Suppress("MissingPermission")
    private fun scanWifi() {
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                requestNeededPermissions(); status.text = "Allow Nearby Wi-Fi devices permission, then tap scan again."; return
            }
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wifi.isWifiEnabled) { status.text = "Turn on Wi-Fi in phone settings, then scan again."; return }
            val started = wifi.startScan()
            val networks = wifi.scanResults.map { "• ${it.SSID.ifBlank { "Hidden network" }} (${it.level} dBm)" }
            status.text = if (started) "Wi-Fi scan requested. Android may limit scan frequency." else "Showing recent Wi-Fi scan results; Android may limit refreshes."
            results.text = if (networks.isEmpty()) "No scan results yet. Try again in a few seconds and check Android permissions." else networks.distinct().joinToString("\n")
        } catch (e: SecurityException) { status.text = "Wi-Fi scan permission missing. Allow nearby-device/location permission in settings." }
    }
}
