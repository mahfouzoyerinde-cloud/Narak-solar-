plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.naraksolar.energy"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.naraksolar.energy"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
