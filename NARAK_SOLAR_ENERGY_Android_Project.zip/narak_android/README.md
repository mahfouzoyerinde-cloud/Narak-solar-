# NARAK SOLAR ENERGY — Android starter project

Orange/white native Android starter app. It has a dashboard placeholder and Bluetooth LE device discovery. It is **not yet a complete BMS monitor**: it does not decode TAICO messages, show verified live battery values, connect to an inverter, or support remote monitoring. Those require the exact device model/protocol and further implementation/testing.

## Build an APK using only an Android phone
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository and upload the contents of this folder (including `.github/workflows/build-apk.yml`). You can upload the ZIP contents using GitHub's web interface or a mobile git client.
3. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
4. Open the completed workflow run, find **Artifacts**, and download `NARAK-SOLAR-ENERGY-debug-apk`. Extract it and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager; only allow this for files you trust.

This is a debug/test APK, not a signed Google Play release. Never install an APK from an unknown source. The build workflow uses GitHub-hosted runners.
