# Narak Solar Energy — Android starter project

Orange-and-white native Android starter app for solar/battery monitoring.

## Current prototype
- Android dashboard UI.
- Clearly marked simulated battery/solar readings.
- Basic display of already-paired Bluetooth devices.
- Requests permissions and reads recent Wi-Fi scan results where Android allows it.
- Project scaffolding for 12V/24V/48V batteries and LiFePO4/lithium/lead-acid systems.

## Important limitations
This is a starter prototype, not a finished production monitoring system and not an APK. It does **not** yet actively discover BLE devices, decode any vendor-specific BMS/inverter protocol, communicate over RS-485/CAN, or provide remote monitoring. Those require the exact hardware/model/protocol and (for remote access) a secure backend. Wi-Fi scan availability is restricted by Android and device manufacturers.

## Build an APK
1. Install Android Studio on a computer and open this folder as a project.
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select **Build > Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

This environment does not have the Android SDK/Gradle build setup available, so an APK has not been compiled here. Package: `com.naraksolar.energy`; minimum Android: 8.0 (API 26).

## Optional phone-only route using GitHub Actions
The repository includes `.github/workflows/build-apk.yml`. If you upload these project files to a GitHub repository, GitHub Actions can build a debug APK in the cloud. On GitHub, open **Actions**, run **Build Android APK** (or push to `main`), then open the completed run and download the `narak-solar-energy-debug-apk` artifact. GitHub account/repository setup is still required; this project has not been uploaded to GitHub by this assistant.
